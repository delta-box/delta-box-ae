#!/usr/bin/env python3
"""Verify this historical supplement and recompute its event-weighted means."""
from pathlib import Path
import collections
import gzip
import hashlib
import json
import math
import statistics

ROOT = Path(__file__).resolve().parent

def require(condition, message):
    if not condition:
        raise ValueError(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def verified_file(item):
    path = ROOT / item['path']
    require(path.resolve().is_relative_to(ROOT), 'Path outside supplement')
    data = path.read_bytes()
    require(digest(data) == item['published_sha256'], 'Published hash mismatch: ' + item['path'])
    return data

def number(row, field):
    value = row[field]
    require(isinstance(value, (int, float)) and not isinstance(value, bool), 'Non-numeric ' + field)
    require(math.isfinite(value) and value >= 0, 'Invalid timing ' + field)
    return value

def main():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    records = manifest['records']
    require(len(records) == manifest['expected_counts']['runs'] == 12, 'Expected 12 runs')
    require(len({r['instance'] for r in records}) == 12, 'Duplicate instances')
    groups = collections.defaultdict(lambda: {'ckpt': [], 'restore': []})
    for record in records:
        compressed = verified_file(record['record'])
        require(digest(compressed) == record['record']['source_sha256'], 'Historical gzip bytes changed')
        raw = gzip.decompress(compressed)
        require(digest(raw) == record['record']['uncompressed_sha256'], 'Raw JSONL hash mismatch')
        conditions = json.loads(verified_file(record['conditions']))
        require(conditions['instance_id'] == record['instance'], 'Instance mismatch')
        require(conditions['run_id'] == record['run_id'], 'Run ID mismatch')
        require(conditions['git_rev'] == manifest['recorded_git_baseline'], 'Recorded Git baseline mismatch')
        rows = [json.loads(line) for line in raw.decode('utf-8').splitlines() if line]
        checkpoints = [row for row in rows if row.get('kind') == 'ckpt']
        restores = [row for row in rows if row.get('kind') == 'restore']
        summaries = [row for row in rows if row.get('kind') == 'run_summary']
        require(len(summaries) == 1 and rows[-1].get('kind') == 'run_summary', 'Missing final summary')
        require(summaries[0].get('error_n') == 0 and summaries[0].get('worker_exec_bad_n') == 0,
                'Historical summary reports errors (these flags do not prove every action succeeded)')
        require(len(checkpoints) == record['checkpoint_events'], 'Checkpoint event count mismatch')
        require(len(restores) == record['restore_events'], 'Restore event count mismatch')
        ck = [number(row, 'ckpt_wall_ms') for row in checkpoints]
        rs = []
        for row in restores:
            value = number(row, 'restore_critical_ms')
            require(number(row, 'restore_wall_ms') == value, 'Historical restore wall/critical mismatch')
            rs.append(value)
        for key in (record['family'], 'TOTAL'):
            groups[key]['ckpt'].extend(ck)
            groups[key]['restore'].extend(rs)
    require(len(groups['TOTAL']['ckpt']) == manifest['expected_counts']['checkpoint_events'] == 317,
            'Expected 317 checkpoints')
    require(len(groups['TOTAL']['restore']) == manifest['expected_counts']['restore_events'] == 334,
            'Expected 334 restores')
    print('Verified 12 unmodified historical gzip records and 12 allowlisted condition exports.')
    print('Historical internal restore interval; not full external API latency.')
    print(f"{'Family':<14} {'Checkpoint n':>12} {'Checkpoint ms':>15} {'Restore n':>10} {'Restore ms':>15}")
    for key in ('Django', 'SymPy', 'Scientific', 'Tools/Small', 'TOTAL'):
        g = groups[key]
        print(f"{key:<14} {len(g['ckpt']):>12} {statistics.mean(g['ckpt']):>15.6f} "
              f"{len(g['restore']):>10} {statistics.mean(g['restore']):>15.6f}")
    print('All 334 historical restore_wall_ms values equal restore_critical_ms.')

if __name__ == '__main__':
    main()
