# Original Table 2 DeltaBox historical source supplement

This package identifies the original twelve-run batch underlying the DeltaBox rows of Table 2. It is historical evidence, not a new VM execution or a claim of independent system reproduction. This formal supplement corrects the Table 2 packaging error: default archived Table 2 analysis uses these original records. The later batch in the public e8b46b0 archive remains available, and other experiments retain their existing inputs.

## Recompute without dependencies

Python 3.10 or newer and its standard library are sufficient. From this directory:

```sh
sha256sum -c SHA256SUMS
python3 recompute.py
```

The script verifies the manifest hashes, twelve unique instances, per-run event counts, 317 checkpoint events, 334 restore events, and equality of every restore_wall_ms and restore_critical_ms value. It concatenates events within each family and computes sum(duration)/number_of_events; it does not average per-run means. The total is 10.827002 ms checkpoint and 1.862881 ms restore, rounding to the paper's 10.83/1.86 ms.

## Contents and provenance

- `records/`: the original twelve gzip files, copied without changing any bytes. Manifest source and publication hashes must be equal. Uncompressed JSONL hashes are also recorded.
- `conditions/`: explicit allowlist exports of recorded run conditions. Measurements are unchanged; unlisted keys are omitted. The manifest preserves source and publication hashes for each condition file and states the allowlist.
- `manifest.json`: per-run identities, original source paths, hashes, counts, and recorded Git baseline.
- `recompute.py`: standalone verification and event aggregation.

Original batch: `finalbench/legacy/deltabox_peagle_mcts30_2x_numa12_realrtt_before_rsfast_20260603_190652`.
Recorded Git baseline: `e200a6ce7deb107ba35a770206b6392f6ef9dac3`.
Runs occurred on June 3, 2026, approximately 00:30-00:42 +08:00. They used 4 vCPU, 8 GiB, real-agent execution, `--no-adaptive --warm-template --prewarm`, and host kernel 5.15.0-177-generic. See each exported condition file for CPU affinity and schedule hash.

The later released batch records Git baseline 19766d81 and host kernel 6.8.0-124-generic. Its same twelve instances and schedule hashes produce 8.324615/1.398972 ms. Different kernels, CPU placements and incomplete source capture prevent attributing that difference to one optimization.

## Limits of this evidence

1. Restore timing is the historical internal fork/ioctl critical interval. The records set restore_wall_ms equal to restore_critical_ms. They do not measure the complete external restore API, which also includes other setup, old-active cleanup and post-processing.
2. Conditions record Git HEAD but do not preserve the deployment's dirty diff or a complete deployed guest source hash. The exact deployed source has not been recovered. Recomputing these records does not establish a complete source-and-environment reproduction.
3. Historical success flags are not sufficient to prove every worker action succeeded. In `django__django-14672.replay-deltabox-no-adapt-c90fc6`, event 14 attempted `python3 -m pytest -q django/tests`; the command returned rc=4 because the path was missing, while the old agent reported ok=true. We retain that original evidence unchanged. The recomputation checks the historical event counts and timing values; it does not repair or endorse these old action checks.
4. This package supplies the numeric source that was absent from the released Table 2 archive. It is not a new performance run and does not reduce differences by scaling results, dropping events, or altering timers.

The current consolidated deviation ledger remains `spr4numa:/mnt/disk2/dyp/deltabox-runtime/ae/report/README.md`; this README only describes the package.
